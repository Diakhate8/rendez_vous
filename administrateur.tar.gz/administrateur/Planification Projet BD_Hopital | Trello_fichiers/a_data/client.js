/* global TrelloPowerUp */
var Promise = TrelloPowerUp.Promise;

// Constants
var BOARD_SETTING_ID = 'risk-matrix-settings';
var CARD_DETAIL_ID = 'risk-matrix-detail';
var DEFAULT_SETTINGS = {
	title: "Matrix for Trello",
	xAxis: {
		title: "Impact",
		options: [
			"Negligible",
			"Minor",
			"Moderate",
			"Significant",
			"Severe"
		]
	},
	yAxis: {
		title: "Likelihood",
		options: [
			"Very Unlikely",
			"Unlikely",
			"Possible",
			"Likely",
			"Very Likely"
		]
	},
	badges: true,
	rich: false
};

// Icons
var CARD_BUTTON_ICON = 'https://ac-cloud.com/card-matrix/images/icon-black.svg';
var WHITE_ICON = 'https://ac-cloud.com/card-matrix/images/icon-white.svg';
var BLACK_ICON = 'https://ac-cloud.com/card-matrix/images/icon-blue.svg';
var SETTINGS_ICON = 'https://ac-cloud.com/card-matrix/images/settings.png';

var getBadge = function(t, opts, detail) {
	return t.get('board', 'shared', BOARD_SETTING_ID, DEFAULT_SETTINGS).then(function(settings) {
		if(!settings) {
			return null;
		} else if(typeof settings.badges === "undefined" || !settings.badges) {
			return null;
		} else {
			return [{
				dynamic: function() {
					return t.get(opts.context.card, 'shared', CARD_DETAIL_ID, null).then(function(data) {
						return new Promise(function (resolve, reject) {
							if (data === null) {
								resolve(null);
							} else if(typeof data.xAxisOption == "undefined" || typeof data.yAxisOption == "undefined") {
								resolve(null);
							} else {
								var badge = {
									text: settings.xAxis.options[parseInt(data.xAxisOption)] + " / " + settings.yAxis.options[parseInt(data.yAxisOption)],
									color: getColor(parseInt(data.xAxisOption), parseInt(data.yAxisOption)),
									refresh: 10,
								};
								if(detail) {
									badge.icon = "https://ac-cloud.com/card-matrix/images/icon-white.svg";
									resolve(badge);
								} else {
									badge.icon = "https://ac-cloud.com/card-matrix/images/icon-white.svg";
									resolve(badge);
								}
							}
						});
					});
				}
			}];
		}
	}).catch(function() {
		return [];
	});
};

function getColor(xIndex, yIndex) {
	if(xIndex === 0 && yIndex < 3 || xIndex === 1 && yIndex < 2 || xIndex === 2 && yIndex < 1) {
		return "green";
	} else if(xIndex === 0 || xIndex === 1 || xIndex === 2 && yIndex < 3 || xIndex === 3 && yIndex < 2) {
		return "yellow";
	} else if(xIndex === 2 || xIndex === 3 && yIndex < 4 || xIndex === 4 && yIndex < 3) {
		return "purple";
	} else {
		return "red";
	}
}

// Initialize Integration Points
TrelloPowerUp.initialize({
	'on-enable': function(t, options) {
		var actions = [];
		if(t.memberCanWriteToModel("board")) {
			actions.push({
				icon: SETTINGS_ICON,
				callback: function(t) {
					return t.popup({
						title: 'Matrix for Trello Settings',
						url: './settings',
						height: 400 // we can always resize later
					});
				},
				alt: 'Settings',
				position: 'left',
			});
		}
		return t.modal({
			title: 'Matrix for Trello Quick Start',
			url: 'start',
			height: 750,
			accentColor: "green",
			actions: actions
		});
	},
	'card-buttons': function(t, options) {
		if(t.memberCanWriteToModel("card")) {
			return [{
				icon: BLACK_ICON,
				text: 'Matrix',
				callback: function (context) {
					return t.get('member', 'private', 'token').then(function (token) {
						if (!token) {
							return context.popup({
								title: 'Authorize Your Account',
								url: './auth',
								height: 75
							});
						} else {
							return context.popup({
								title: "Matrix for Trello",
								url: 'edit',
								height: 210
							});
						}
					});
				}
			}];
		} else {
			return [];
		}
	},
	'board-buttons': function (t, opts) {
		return [{
			text: 'Matrix',
			icon: BLACK_ICON,
			callback: function() {
				return t.get('board', 'shared', BOARD_SETTING_ID, DEFAULT_SETTINGS).then(function(settings) {
					var actions = [];
					if(t.memberCanWriteToModel("board")) {
						actions.push({
							icon: SETTINGS_ICON,
							callback: function(t) {
								return t.popup({
									title: 'Matrix for Trello Settings',
									url: './settings',
									height: 400 // we can always resize later
								});
							},
							alt: 'Settings',
							position: 'left',
						});
					}
					return t.modal({
						title: settings.xAxis.title + "/" + settings.yAxis.title + " Matrix",
						url: 'matrix',
						fullscreen: true,
						accentColor: "green",
						actions: actions
					});
				});
			},
			condition: 'edit'
		}];
	},
	'show-settings': function(t, options){
		return t.popup({
			title: 'Matrix for Trello Settings',
			url: './settings',
			height: 400 // we can always resize later
		});
	},
	'list-actions': function (t) {
		return t.list('name', 'id')
			.then(function (list) {
				var actions = [];
				if(t.memberCanWriteToModel("board")) {
					actions.push({
						text: "Bulk Change Matrix",
						callback: function (t) {
							return t.popup({
								title: 'Bulk Change Matrix',
								url: 'edit?list=' + list.id,
								height: 232
							});
						}
					});
				}
				return actions;
			});
	},
	'card-badges': function (t, opts) {
		return getBadge(t, opts, false);
	},
	'card-detail-badges': function (t, opts) {
		return getBadge(t, opts, true);
	},
	'show-authorization': function(t){
		return t.popup({
			title: 'Authorize Your Account',
			url: './auth-standalone',
			height: 75
		});
	},
	'authorization-status': function(t, options){
		return t.get('member', 'private', 'token').then(function(token) {
			return !token ? {authorized: false} : {authorized: true};
		});
	},
	'remove-data': function(t){
		return t.remove('member', 'private', 'token');
	}
}, {
	appKey: "968dbd9ff10f81391aa1b8261214b2ae",
	appName: "Matrix for Trello"
});
