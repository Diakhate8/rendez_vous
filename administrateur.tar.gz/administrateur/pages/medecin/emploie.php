<?php
session_start();
require_once "../../classes/connexionbd.php";require_once "../../classes/tables.php";
//$db = new Mabase();
if(isset($_SESSION['id']) AND isset($_GET['id']) AND $_SESSION['id'] == $_GET['id']){
    $idS=intval($_GET['id']);
   //echo $_SESSION['id'] .'<br>'.  $_SESSION['pseudo'] .'<br>'. $_SESSION['statut'].'<br>';
    $mdc = new Table() ;
    $table='Planing';
    $champ='Id_Medecin';
    $id=$idS;
    $donnes=$mdc->select1($table,$champ,$id);
    if(isset($_POST['ajouter'])){
        if(!empty($_POST['datedebut'])){

        }
        if(!empty($_POST['datefin'])){
            
        }
        if(!empty($_POST['heuredebut'])){
            
        }
        if(!empty($_POST['heurefin'])){
            
        }
        if(!empty($_POST['lundu'])){
            
        }
        if(!empty($_POST['mardi'])){
            
        }
        if(!empty($_POST['mercredi'])){
            
        }
        if(!empty($_POST['jeudi'])){
            
        }
        if(!empty($_POST['vendredi'])){
            
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
  <title>emploie du temps medecins</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/emploie.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
<div>    <!--barnav-->
    <nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="197">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                </button>
                <a class="navbar-brand" href="#">Medecins</a>
            </div>
        </div>
    </nav>   
    <br>
    <h1 class="text-center">Emploie du temps medecin</h1>
</div> 
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12 col-md-8 col-lg-9">     <!--Tableau d'affichage-->
                <table>                   
                    <tr>
                    <th>Id medecin</th><th>Date debut</th><th>Date fin</th><th>Date debut</th> <th>Date fin</th><th>Heure debut</th><th>Heure fin</th>
                    </tr>
                    <tr>    
                        <th>Lundi</th>
                        <th>Mardi</th>
                        <th>Mercredi</th>
                        <th>Jeudi</th>
                        <th>Vendredi</th>
                        <th>Actions </th>        
                    </tr>   
                        <tr id="myTable">
                            <td>d_Medecin</td>
                            <td>Prenom_Medecin</td>
                            <td>Nom_Medecin</td>
                            <td>Datedenaiss_Medecin</td>
                            <td>Adresse_Medecin</td>
                            <td>Telephone_Medecin</td>
                            <td>d_Domaine</td>
                            <td>d_Service</td>
                            <td><a href='modifemployer.php?ok=$tab[0]'>
                            <button class="btn btn-warning">Modifer</a> &nbsp;
                                <a href='tsupemployer.php?ok=$tab[0]' onclick='return confirmation();'>
                            <button class="btn btn-danger ">Supprimer</a>                   
                            </td>
                        </tr>
                </table>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-4 ">    
            <form method="POST"  action="">
               <table class="table-center">
                    <tr><th colspan="2"><legend>Ajouter Planing</legend></th></tr>
                    <div class="form-group">
                        <tr>
                            <td><label for="idmedecin">Id medecin: </label></td>
                            <td><input type="text" name="idmedecin" class="form-control"></td>
                        </tr>
                    </div>
                    <div class="form-group">
                        <tr>
                            <td><label for="datedebut">Date debut: </label></td>
                            <td><input type="text" name="datedebut" class="form-control"></td>
                        </tr>
                    </div>
                    <div class="form-group">
                        <tr>
                            <td><label for="datefin">Date fin: </label></td>
                            <td><input type="text" name="datefin" class="form-control"></td>
                        </tr>
                    </div>
                    <div class="form-group">
                        <tr>
                            <td><label for="heuredebut">Heure debut: </label></td>
                            <td><input type="date" name="heurefin" class="form-control"></td>
                        </tr>
                    </div>
                    
                    <div class="form-group">
                        <tr>
                            <td><label for="heurefin">Heurefin: </label></td>
                            <td><input type="text" name="heurefin" class="form-control"></td>
                        </tr>
                    </div>
                    <div class="form-group">
                        <tr>
                            <td><label for="lundi">Lundi: </label></td>
                            <td><input type="text" name="lundi" class="form-control"></td>
                        </tr>
                    </div>
                    <div class="form-group">
                        <tr>
                            <td><label for="mardi">Mardi: </label></td>
                            <td><input type="text" name="mardi" class="form-control"></td>
                        </tr>
                    </div>
                    <div class="form-group">
                        <tr>
                            <td><label for="mercredi">Mercredi: </label></td>
                            <td><input type="text" name="mercredi" class="form-control"></td>
                        </tr>
                    </div>
                    <div class="form-group">
                        <tr>
                            <td><label for="jeudi">Jeudi: </label></td>
                            <td><input type="text" name="jeudi" class="form-control"></td>
                        </tr>
                    </div>
                    <div class="form-group">
                        <tr>
                            <td><label for="vendredi">Vendredi: </label></td>
                            <td><input type="text" name="vendredi" class="form-control"></td>
                        </tr>
                    </div>
                    
                    <div class="form-group">
                        <tr><td></td>
                            <td style="text-align:center">
                            <button type="submit" name="ajouter" class="btn btn-primary">Ajouter</button>
                            </td>
                        </tr>
                    </div>                
            </table>
                <div id="erreur"><?php  if (isset($erreur)){echo $erreur ;}?></div>
            </form>  
        </div>


    </div>
</div>    
</body>
</html>

<?php    
}
?>