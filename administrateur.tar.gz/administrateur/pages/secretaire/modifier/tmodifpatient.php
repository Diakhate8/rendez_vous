<?ph
session_start();
require_once "../../classes/connexionbd.php";require_once "../../classes/tables.php";
header('location:listemployer.php');
    }

?>