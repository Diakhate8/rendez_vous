<?php
session_start();
$db=new PDO('mysql:host=localhost;dbname=RDV_HOPITAL','root','root') or die('error');

if(isset($_SESSION['id'])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Inscription Secretaires</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/inscription.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="jquery/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
  </head>
    <body data-spy="scroll" data-target=".navbar" data-offset="50">

    <!--barnav-->
    <nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="197">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                </button>
            <a class="navbar-brand" href="#">menu</a>
            </div>
           
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
               <!-- <li><a href="pages/admin1.php">Page Admin</a></li>-->
                 </ul>
                <ul class="nav navbar-nav navbar-right">
                <?php
                   // if(isset($_SESSION['id']) AND $userinfos['Id'] == $_SESSION['id']){
                ?>
                   <li><a href="../../deconnexion.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                <?php
                  //  }
                ?>
                </ul>    
            </div>
        </div>
    </nav>  
<div class="container">
  <div class="row">
    <div class="col-sm-6 col-md-6 col-lg-6 bg-warning ">
        <h1><span class="acceuil">Formulaire D'inscription Des Secretaires</span></h1> 
    </div> 
    <div class="col-sm-6 col-md-6 col-lg-6 bg-danger">    
      <form method="POST"  action="">
          <table class="table-center">
                <tr><th colspan="2"><legend>Inscription</legend></th></tr>
                
                <div class="form-group">
                    <tr>
                        <td><label for="prenom">Prenom: </label></td>
                        <td><input type="text" name="prenom" class="form-control"></td>
                    </tr>
                </div>
                <div class="form-group">
                    <tr>
                        <td><label for="nom">Nom: </label></td>
                        <td><input type="text" name="nom" class="form-control"></td>
                    </tr>
                </div>
                <div class="form-group">
                    <tr>
                        <td><label for="datenaiss">Date de naissance: </label></td>
                        <td><input type="text" name="datenaiss" class="form-control"></td>
                    </tr>
                </div>
                
                <div class="form-group">
                    <tr>
                        <td><label for="adresse">Adresse: </label></td>
                        <td><input type="text" name="adresse" class="form-control"></td>
                    </tr>
                </div>
                <div class="form-group">
                    <tr>
                        <td><label for="telephone">Telephone: </label></td>
                        <td><input type="text" name="telephone" class="form-control"></td>
                    </tr>
                </div>
                <div class="form-group">
                    <tr>
                        <td><label for="idservice">Id Service: </label></td>
                        <td><select  name="idservice" class="form-control">
                            <option>1</option><option>2</option><option>3</option>
                            <option>4</option><option>5</option><option>6</option>
                            <option>7</option><option>8</option><option>9</option>
                            <option>10</option><option>12</option><option>13</option>
                            <option>14</option>
                            </select>
                        </td>>
                    </tr>
                </div>
                <div class="form-group">
                    <tr><td></td>
                        <td style="text-align:center">
                        <button type="submit" name="enregistrer" class="btn btn-primary">Enregistrer</button>
                        </td>
                    </tr>
                </div>
                
        </table>
              <div id="erreur"><?php  if (isset($erreur)){echo $erreur ;}?></div>
      </form>  
    </div>
  </div>  
</div>
</body>
</html>
<?php
require_once "../../classes/connexionbd.php";require_once "../../classes/tables.php";
//insertion de donneess
$db = new Mabase();
$Ins = new Table ;
$Nomtable = 'Secretaires';

if(isset($_POST['enregistrer'])){

    if( !empty($_POST['prenom']) AND !empty($_POST['nom'])AND !empty($_POST['datenaiss'])
        AND !empty($_POST['adresse']) AND !empty($_POST['telephone']) 
        AND !empty($_POST['idservice'])){

        $prenom = trim(htmlspecialchars($_POST['prenom'])); 
        $nom = trim(htmlspecialchars($_POST['nom']));  
        $datenaiss = trim($_POST['datenaiss']);
        $adresse = trim(htmlspecialchars($_POST['prenom'])); 
        $telephone  = trim(htmlspecialchars($_POST['telephone']));  
        $idservice = trim(htmlspecialchars($_POST['idservice']));
        
        if(preg_match('#^(78||77||76||70)[0-9]{7}$#',$telephone)){
            $donnes = ['Prenom_Secretaire'=>$prenom,'Nom_Secretaire'=>$nom,'Datedenaiss_Secretaire'=>$datenaiss,'Adresse_Secretaire'=>$adresse,'Telephone_Secretaire'=>$telephone ,'Id_Service'=> $idservice];
            $req = $Ins->insert($Nomtable,$donnes);
        }else{$erreur="Entrez un numero valide"; }

    }else{echo "Veuillez saisire toutes les champs";   }
            
} 
?>
<?php    
}
?>