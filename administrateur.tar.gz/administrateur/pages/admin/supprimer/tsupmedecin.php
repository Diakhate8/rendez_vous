<?php
session_start();
require_once "../../../classes/connexionbd.php";require_once "../../../classes/tables.php";
    if(isset($_GET['id'])){
       $id=intval($_GET['id']) ; 
       $req=new Table();      
       $Nomtable= 'Medecins';
       $nomid='Id_Medecin';
       $result = $req->delete($Nomtable,$nomid,$id)  ;        //contenue du variable matricule d'url affecter dans une nouvvel variable
       if($result){
        if(isset($_SESSION['id'])){
        header("location:../ajoutmedecins.php?id=".$_SESSION['id']);}
            }else{echo "echec de suppression ";}
    }

?>