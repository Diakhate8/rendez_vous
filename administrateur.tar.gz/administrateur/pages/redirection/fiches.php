<?php
session_start();
$_SESSION = array();
header('location:../../pgAj/fiches.php');

?>
